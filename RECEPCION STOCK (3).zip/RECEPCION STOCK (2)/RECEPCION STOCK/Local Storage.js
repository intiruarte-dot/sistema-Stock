let equipos = JSON.parse(localStorage.getItem('datos_recepcion')) || [];

document.getElementById('fecha').value = new Date().toISOString().slice(0, 16);
render();

function agregarFila() {
    const caja = document.getElementById('tCaja').value;
    const modelo = document.getElementById('tModelo').value;
    const serie = document.getElementById('tSerie').value;
    const estado = document.getElementById('tEstado').value;
    const estetico = document.getElementById('tEstetico').value;
    // Capturamos el valor exacto del nuevo select de problemática
    const problematica = document.getElementById('tProblematica').value;

    if (!caja || !modelo || !serie) {
        alert("Faltan datos");
        return;
    }

    const nuevo = { caja, modelo, serie, estado, estetico, problematica, id: Date.now() };
    equipos.push(nuevo);
    guardarYRenderizar();

    document.getElementById('tSerie').value = '';
    document.getElementById('tSerie').focus();
}

function render() {
    const tbody = document.querySelector('#tablaDatos tbody');
    if (!tbody) return; // Seguridad por si el elemento no existe en el HTML

    tbody.innerHTML = '';

    equipos.forEach(eq => {
        const fila = `
            <tr>
                <td style="color: #ffffff;">${eq.caja}</td>
                <td style="color: #ffffff;">${eq.modelo}</td>
                <td style="color: #ffffff;"><code>${eq.serie}</code></td>
                <td style="color: #ffffff;">${eq.estado}</td>
                <td style="color: ${eq.estetico === 'SI' ? '#f59e0b' : '#ffffff'}; font-weight: bold;">
                    ${eq.estetico}
                </td>
                <td style="color: #ffffff;">${eq.problematica}</td>
                <td><button class="btn-delete" onclick="eliminar(${eq.id})">
                    <i class="fas fa-trash-alt"></i> Borrar
                </button></td>
            </tr>`;
        tbody.insertAdjacentHTML('beforeend', fila);
    });

    const countLabel = document.getElementById('countEquipos');
    if (countLabel) countLabel.innerText = equipos.length;
}

function eliminar(id) {
    equipos = equipos.filter(e => e.id !== id);
    guardarYRenderizar();
}

function eliminarTodo() {
    if (confirm("¿Borrar todos los equipos registrados?")) {
        equipos = [];
        guardarYRenderizar();
    }
}

function guardarYRenderizar() {
    localStorage.setItem('datos_recepcion', JSON.stringify(equipos));
    render();
}

function exportarExcel() {
    if (equipos.length === 0) return alert("No hay datos para exportar.");

    // Mapeo para que los encabezados coincidan con el Excel solicitado
    const datosParaExcel = equipos.map(eq => ({
        "Caja": eq.caja,
        "Modelo": eq.modelo,
        "Mac Etiqueta": eq.serie, // Cambiado de 'serie'
        "Estado": eq.estado,
        "Daño Estético": eq.estetico, // Cambiado de 'estetico'
        "Problemática": eq.problematica,
        "Fecha Registro": document.getElementById('fecha').value
    }));

    const hoja = XLSX.utils.json_to_sheet(datosParaExcel);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, "Recepcion");

    XLSX.writeFile(libro, `Reporte_Recepcion_${Date.now()}.xlsx`);
}